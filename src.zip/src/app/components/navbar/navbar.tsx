import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '../../lib/supabaseClient';
import { useRouter } from 'next/navigation';

interface UserData {
  email: string;
  role: 'comprador' | 'organizador' | 'vendedor';
}

export default function Navbar() {
  const [userData, setUserData] = useState<UserData | null>(null);
  const router = useRouter();

    async function logOut(){
        supabase.auth.signOut();
        router.push('/login');
    }

  useEffect(() => {
    async function fetchUserRole() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('users')
        .select('email, role')
        .eq('email', user.email)
        .single();

      if (error) console.error('Error fetching role:', error);
      setUserData(data);
    }

    fetchUserRole();
  }, []);

  return (
    <nav className="bg-blue-600 text-white py-4 px-6 shadow-md">
      <div className="flex justify-between items-center max-w-6xl mx-auto">
        <Link href="/buyer">
          <span className="text-xl font-bold cursor-pointer">TicketChange</span>
        </Link>

        {/* Dynamic Navigation */}
        <div className="hidden md:flex space-x-6">
          <Link href="/buyer"><span className="hover:underline cursor-pointer">Dashboard</span></Link>

          {userData?.role === 'organizador' && (
            <Link href="/organizador"><span className="hover:underline cursor-pointer">Event Organizer</span></Link>
          )}
          {userData?.role === 'vendedor' && (
            <Link href="/vendedor"><span className="hover:underline cursor-pointer">Seller Panel</span></Link>
          )}
        </div>

        

        {/* Logout */}
        {userData ? (
          <button className="bg-red-500 px-4 py-2 rounded-lg hover:bg-red-600" onClick={() => logOut()}>
            Logout
          </button>
        ) : (
          <div className="space-x-4">
            <Link href="/login">
              <button className="bg-white text-blue-600 px-4 py-2 rounded-lg hover:bg-gray-200">Login</button>
            </Link>
            <Link href="/signup">
              <button className="bg-green-500 px-4 py-2 rounded-lg hover:bg-green-600">Sign Up</button>
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}
