export default function Home() {
  return (
  <h1>This is the login page</h1>
  );
}
