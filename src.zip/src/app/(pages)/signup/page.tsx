"use client"
import { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { AuthCredentials } from '../../types/auth';

export default function Signup() {
  const [credentials, setCredentials] = useState<AuthCredentials>({ email: '', password: '' });

  const handleSignUp = async () => {
    const { error } = await supabase.auth.signUp(credentials);
    if (error) alert(error.message);
    else alert('Signup successful! Check your email for verification.');
  };

  return (
    <div className="flex h-screen items-center justify-center bg-gray-100">
      <div className="w-full max-w-sm p-6 bg-white rounded-lg shadow-md">
        <h1 className="text-xl font-bold text-center mb-6">Sign Up</h1>
        <input 
          type="email" 
          placeholder="Email" 
          onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-3"
        />
        <input 
          type="password" 
          placeholder="Password" 
          onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
        />
        <button 
          onClick={handleSignUp} 
          className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600"
        >
          Sign Up
        </button>
      </div>
    </div>
  );
}
