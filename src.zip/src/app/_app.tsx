import { useEffect, useState } from 'react';
import { supabase } from './lib/supabaseClient';
import { Session } from '@supabase/supabase-js';

export default function MyApp({ Component, pageProps }: { Component: any; pageProps: any }) {
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
  }, []);

  return session ? <Component {...pageProps} /> : <p>Loading...</p>;
}
